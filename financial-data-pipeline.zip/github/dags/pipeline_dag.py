from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator
from datetime import datetime, timedelta

default_args = {
    "owner": "bhavika",
    "retries": 2,
    "retry_delay": timedelta(minutes=5),
    "email_on_failure": True,
    "email_on_retry": False,
}

with DAG(
    dag_id="nse_trade_pipeline",
    default_args=default_args,
    description="NSE trade data ETL — extract, transform, load to Snowflake",
    schedule_interval="0 6 * * 1-5",   # weekdays at 6 AM IST
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=["finance", "etl", "snowflake"],
) as dag:

    extract = BashOperator(
        task_id="extract_nse_data",
        bash_command="python /app/extraction/ingest.py",
    )

    transform = BashOperator(
        task_id="pyspark_transform",
        bash_command="python /app/transformation/transform_spark.py",
    )

    load_snowflake = BashOperator(
        task_id="load_to_snowflake",
        bash_command="python /app/sql/load_snowflake.py",
    )

    reconcile = BashOperator(
        task_id="reconciliation_check",
        bash_command="python /app/sql/reconcile.py",
    )

    # DAG dependency chain
    extract >> transform >> load_snowflake >> reconcile
